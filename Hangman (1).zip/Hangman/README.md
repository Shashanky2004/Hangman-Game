# Hangman-NLP

## Purpose

This code can play a game of hangman, given a word with blank spaces and 6 guesses (head, body, arms and legs) will return the best letter to guess.

## Methodology

To determine the best guess, the model uses [n-gram](https://en.wikipedia.org/wiki/N-gram) counts. N-grams are typically used to determine the likelihood of a word following another, but in this case we will use it for letters.

In this case, the model uses n-grams from 1 (unigram), 2 (bigram) up to 5 (five-gram). Five is the chosen cutoff because most 6 and above letter sequences begin to be just a chain of smaller sequences.

The model is trained on a dictionary of approximately 250,000 words. This dictionary is used to determine the n-gram frequencies. For example, the following structure for the bigram frequencies are:

* word length (n-gram frequencies depend on length of the word)
    * first letter
        * second letter
            * second letter frequency (this indicates how many letter1-letter2 sequences there are)
            

Feel free to test on your own dictionary, or to enter words you can think of

Run test.py
